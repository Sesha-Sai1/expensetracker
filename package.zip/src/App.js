import "./App.css";
import ExpenseTraker from "./components/ExpenseTraker";

function App() {
  return (
    <div className="App">
      <ExpenseTraker />
    </div>
  );
}

export default App;
